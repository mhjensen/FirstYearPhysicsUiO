This IPython notebook slides.ipynb does not require any additional
programs.
